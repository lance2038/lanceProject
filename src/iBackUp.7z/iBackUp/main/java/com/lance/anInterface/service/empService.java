package com.lance.anInterface.service;

import com.lance.anInterface.bean.Employee;

import java.util.List;

/**
 * @author lance
 * @version v0.0.1
 * @project lanceProject
 * @describe
 * @since 2017/11/22
 **/
public interface empService
{
    public List<Employee> getAllEmps();
}
